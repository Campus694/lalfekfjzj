package com.example.paymenthelper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reads the balance from the bank's home-screen widget after the user taps its refresh button.
 *
 * Flow: a tap on the launcher (or the bank app) schedules a read in [READ_DELAY_MS].
 * After the delay the visible text of the active window is scanned, the balance is saved,
 * and Payment Helper is brought to the front to show it.
 * Nothing is clicked by the service; it only observes taps and reads text.
 */
class BankAccessibilityService : AccessibilityService() {

    companion object {
        private const val PREFS = "payment_helper"
        private const val READ_DELAY_MS = 10_000L   // first read after the tap
        private const val RETRY_MS = 1_000L         // re-read interval while the widget lags
        private const val GIVE_UP_MS = 25_000L      // stop waiting and show whatever was found

        fun beginCheck(context: Context, packageName: String) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString("check_package", packageName)
                .apply()
        }
    }

    private data class Reading(val balance: String, val dateText: String?) {
        val key: String get() = "$balance|${dateText.orEmpty()}"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val readRunnable = Runnable { readBalanceAndShow() }
    @Volatile private var homePackages: Set<String> = emptySet()
    @Volatile private var tapAt: Long = 0L
    @Volatile private var baselineKey: String? = null

    private val labelRegex = Regex("(?i)баланс|доступно|остаток|available|balance")
    private val dateRegex = Regex("\\d{2}\\.\\d{2}\\.\\d{4}\\s+\\d{2}:\\d{2}")
    private val amountRegex = Regex("\\d(?:[\\d\\s\\u00A0'.,]*\\d)?")
    private val currencyRegex = Regex("(?i)₽|руб\\.?|BYN|RUB|USD|EUR|€|\\$|бел\\.\\s*руб\\.?")
    private val amountWithCurrencyRegex = Regex("(?i)^($amountRegex)\\s*($currencyRegex)$")
    private val labelAmountRegex = Regex("(?i)(?:баланс|доступно|остаток|available|balance)\\D{0,20}?($amountRegex)\\s*($currencyRegex)?")

    override fun onServiceConnected() {
        super.onServiceConnected()
        @Suppress("DEPRECATION")
        homePackages = packageManager
            .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_ALL)
            .mapNotNull { it.activityInfo?.packageName }
            .toSet()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return
        val source = event.packageName?.toString() ?: return
        if (source in homePackages || source == bankPackage()) {
            // A new tap restarts the wait; the widget value must change before we accept it.
            val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            baselineKey = prefs.getString("last_key", null)
            tapAt = System.currentTimeMillis()
            handler.removeCallbacks(readRunnable)
            handler.postDelayed(readRunnable, READ_DELAY_MS)
        }
    }

    private fun readBalanceAndShow() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()
        val reading = if (root != null && (pkg in homePackages || pkg == bankPackage())) {
            val texts = mutableListOf<String>()
            collectVisibleText(root, texts, 0)
            extractReading(texts)
        } else null

        val elapsed = System.currentTimeMillis() - tapAt
        // The widget lags: keep re-reading until the value differs from the one shown before the tap.
        if (elapsed < GIVE_UP_MS && (reading == null || reading.key == baselineKey)) {
            handler.postDelayed(readRunnable, RETRY_MS)
            return
        }
        handler.removeCallbacks(readRunnable)

        val editor = prefs.edit().putLong("last_balance_time", System.currentTimeMillis())
        if (reading != null) {
            editor.putString("last_balance", reading.balance)
                .putString("last_balance_date", reading.dateText)
                .putString("last_key", reading.key)
                .putString("last_status", "Баланс прочитан с виджета банка.")
        } else {
            editor.putString("last_status", "Баланс не найден. Проверьте, что виджет показывает сумму.")
        }
        editor.apply()

        // Bring Payment Helper to the front to show the result.
        packageManager.getLaunchIntentForPackage(packageName)?.let { ownIntent ->
            ownIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            try { startActivity(ownIntent) } catch (_: Exception) { }
        }
    }

    private fun bankPackage(): String? {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString("check_package", null) ?: prefs.getString("selected_package", null)
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 500) return
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        }
        for (i in 0 until node.childCount) collectVisibleText(node.getChild(i), out, depth + 1)
    }

    /**
     * The widget may give the amount as one node ("0.57 BYN") or as several nodes ("Карта 1", "0.57", "BYN").
     * Labelled amounts win; otherwise the first amount followed by a currency is used.
     * Plain numbers without a currency are never accepted (e.g. "#5083" or "Карта 1").
     */
    private fun extractReading(texts: List<String>): Reading? {
        val dateText = dateRegex.find(texts.joinToString(" | "))?.value
        var fallback: String? = null

        for (i in texts.indices) {
            val text = texts[i]

            labelAmountRegex.find(text)?.let { m ->
                val amount = m.groupValues[1]
                val currency = m.groupValues[2]
                return Reading(clean(if (currency.isEmpty()) amount else "$amount $currency"), dateText)
            }

            amountWithCurrencyRegex.find(text)?.let { m ->
                val candidate = clean("${m.groupValues[1]} ${m.groupValues[2]}")
                if (hasLabelBefore(texts, i)) return Reading(candidate, dateText)
                if (fallback == null) fallback = candidate
            }

            if (amountRegex.matches(text) && i + 1 < texts.size && currencyRegex.matches(texts[i + 1])) {
                val candidate = clean("$text ${texts[i + 1]}")
                if (hasLabelBefore(texts, i)) return Reading(candidate, dateText)
                if (fallback == null) fallback = candidate
            }
        }
        return fallback?.let { Reading(it, dateText) }
    }

    private fun hasLabelBefore(texts: List<String>, index: Int): Boolean =
        (maxOf(0, index - 3) until index).any { labelRegex.containsMatchIn(texts[it]) }

    private fun clean(s: String): String = s.replace(Regex("[\\s\\u00A0]+"), " ").trim()

    override fun onInterrupt() {
        handler.removeCallbacks(readRunnable)
    }
}
