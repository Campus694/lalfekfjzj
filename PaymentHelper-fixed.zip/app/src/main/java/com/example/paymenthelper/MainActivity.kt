package com.example.paymenthelper

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

data class InstalledApp(val label: String, val packageName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PaymentHelperScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PaymentHelperScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("payment_helper", Context.MODE_PRIVATE) }
    var selectedPackage by remember { mutableStateOf(prefs.getString("selected_package", null)) }
    var selectedLabel by remember { mutableStateOf(prefs.getString("selected_label", null)) }
    var showPicker by remember { mutableStateOf(false) }
    var balance by remember { mutableStateOf(prefs.getString("last_balance", null)) }
    var balanceDate by remember { mutableStateOf(prefs.getString("last_balance_date", null)) }
    var status by remember { mutableStateOf("Выберите банковское приложение.") }

    val installedApps = remember {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
                if (packageName == context.packageName) return@mapNotNull null
                InstalledApp(info.loadLabel(pm).toString(), packageName)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun serviceEnabled(): Boolean {
        val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == context.packageName &&
                   it.resolveInfo.serviceInfo.name == BankAccessibilityService::class.java.name }
    }

    // Does not open the bank app. Tell the user to tap the widget refresh; the service
    // reads the balance 10 seconds after that tap and brings this screen back to the front.
    fun startCheck() {
        if (selectedPackage == null) {
            status = "Сначала выберите банковское приложение."
            showPicker = true
            return
        }
        if (!serviceEnabled()) {
            status = "Включите службу доступности Payment Helper один раз в настройках Android."
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        BankAccessibilityService.beginCheck(context, selectedPackage!!)
        status = "Нажмите обновление на виджете банка на главном экране. Через 10 секунд баланс появится здесь."
    }

    LaunchedEffect(Unit) {
        while (true) {
            val timestamp = prefs.getLong("last_balance_time", 0L)
            if (timestamp > 0L && timestamp > prefs.getLong("shown_balance_time", 0L)) {
                balance = prefs.getString("last_balance", null)
                balanceDate = prefs.getString("last_balance_date", null)
                status = prefs.getString("last_status", null) ?: status
                prefs.edit().putLong("shown_balance_time", timestamp).apply()
            }
            delay(500)
        }
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Payment Helper") }) }) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Банковское приложение", style = MaterialTheme.typography.titleMedium)
                OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(selectedLabel ?: "Выбрать приложение")
                }
                Button(
                    onClick = { startCheck() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Проверить настройку виджета")
                }
                Text(status, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider()
                Text("Последний найденный баланс", style = MaterialTheme.typography.titleMedium)
                Text(balance ?: "Пока нет данных", style = MaterialTheme.typography.headlineSmall)
                balanceDate?.let { Text("на $it", style = MaterialTheme.typography.bodySmall) }
                Text(
                    "Данные читаются локально с видимого текста виджета или экрана выбранного приложения. " +
                    "Сервис не нажимает кнопки и не отправляет информацию в интернет.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedButton(
                    onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Настройки службы доступности") }
            }
        }

        if (showPicker) {
            AlertDialog(
                onDismissRequest = { showPicker = false },
                title = { Text("Выберите приложение") },
                text = {
                    LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                        items(installedApps, key = { it.packageName }) { app ->
                            TextButton(
                                onClick = {
                                    selectedPackage = app.packageName
                                    selectedLabel = app.label
                                    prefs.edit()
                                        .putString("selected_package", app.packageName)
                                        .putString("selected_label", app.label)
                                        .apply()
                                    showPicker = false
                                    status = "Выбрано: ${app.label}"
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(app.label)
                                    Text(app.packageName, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showPicker = false }) { Text("Закрыть") }
                }
            )
        }
    }
}
