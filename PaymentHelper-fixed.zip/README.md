# Payment Helper

Android app scaffold: Kotlin, Jetpack Compose, Material 3, minSdk 26.

## Build APK
Open this folder in Android Studio (JDK 17; Android SDK 35), wait for Gradle sync, then run:
`gradle assembleDebug`
APK output: `app/build/outputs/apk/debug/app-debug.apk`

Or push the project to a GitHub repository and run the included **Build Android APK** workflow. Download the `PaymentHelper-debug-apk` artifact from the workflow run.

## Install / use
1. Install the APK.
2. Open Payment Helper once, choose the bank app.
3. Enable **Payment Helper balance reader** in Android Settings > Accessibility. This is needed only once; the service stays on.
4. From then on, on the home screen, tap the refresh icon on the bank's balance widget. Wait about 10 seconds: the balance is read from the widget text and Payment Helper opens to show it. You do not need to open the bank app.

## Notes
- Works only while the home-screen widget shows the balance as text. Some launchers or bank widgets may not expose text to accessibility; this is a best-effort prototype.
- The service only observes taps and reads visible text from the launcher and the selected bank package. It does not click or tap controls for you, does not read password fields, transmit data, or bypass bank protections.
- Test only with your own account/device and follow your bank's terms.
